<div class='banner-servicos'>
    <div class="w3-display-container">
        <div class="banner-home mySlides w3-animate-zoom w3-animate-opacity b1">
            
        </div>
    </div>
</div>
