<section style="background-image: url('core/imagens/banner-areas.webp'); background-size: cover; padding-top: 50px; padding-bottom: 70px; margin-top:50px">
        <h3 style="text-align: center; font-size: 30pt; line-height: 32pt; color: #fff; margin-bottom: 100px">EM QUAL ÁREA DE ATUAÇÃO<BR>NÓS PODEMOS TE AJUDAR?</h3>
            <div class="linha">

                <div class="colunas lg-1 md-12 pq-12">
                    &nbsp;
                </div>
                
                <div class="colunas lg-2 md-6 pq-12">
                    <a href="areas-de-atuacao/direito-civil" target="_parent" title="Direito Civil">
                    <div class='box'>
                        <div class="icone-servico direito-civil"></div>
                        <h3>Direito Civil</h3>
                        
                    </div>
                    </a>
                </div>

                <div class="colunas lg-2 md-6 pq-12">
                    <a href="areas-de-atuacao/direito-penal" target="_parent" title="Direito Penal">
                        <div class='box'>
                            <div class="icone-servico direito-penal"></div>
                            <h3>Direito Penal</h3>
                            
                        </div>
                        </a>
                </div>

                <div class="colunas lg-2 md-6 pq-12">
                    <a href="areas-de-atuacao/direito-empresarial" target="_parent" title="Direito Empresarial">
                        <div class='box'>
                            <div class="icone-servico direito-empresarial"></div>
                            <h3>Direito Empresarial</h3>
                            
                        </div>
                        </a>
                </div>

                <div class="colunas lg-2 md-6 pq-12">
                    <a href="areas-de-atuacao/falencia-e-recuperacao-judicial" target="_parent" title="Falência e Recuperação Judicial">
                        <div class='box'>
                            <div class="icone-servico falencia_recuperacao"></div>
                            <h3>Falência e Recuperação Judicial</h3>
                       
                        </div>
                        </a>
                </div>

                <div class="colunas lg-2 md-6 pq-12">
                    <a href="areas-de-atuacao/outras-areas" target="_parent" title="Outras áreas">
                        <div class='box'>
                            <div class="icone-servico outras-areas"></div>
                            <h3>Outras Áreas</h3>
                       
                        </div>
                        </a>
                </div>

                <div class="colunas lg-1 md-12 pq-12">
                    &nbsp;
                </div>

            </div>

</section>