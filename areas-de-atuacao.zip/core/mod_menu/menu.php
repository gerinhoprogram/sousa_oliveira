<link rel="stylesheet" type="text/css" href="core/css/menu_resp.css">
<nav>
    <label for="drop" class="toggle barras" style="border:none;"><i class="fa fa-bars" aria-hidden="true"></i></label>
    <input type="checkbox" id="drop" />
    <ul class="menu_resp">
        <li>
            <a href='contato' target="_parent" title="Contato" class='toggle submenu'>Contato</a>
            <a href='contato' target="_parent" title="Contato">Contato</a>
        </li>
        <li>
            <a href='areas-de-atuacao' target="_parent" title="Áreas de atuação" class='toggle submenu'>Áreas de atuação</a>
            <a href='areas-de-atuacao' target="_parent" title="Áreas de atuação">Áreas de atuação</a>
        </li>
        <li>
            <a href='nossos-profissionais' target="_parent" title="Nossos profissionais" class='toggle submenu'>Nossos profissionais</a>
            <a href='nossos-profissionais' target="_parent" title="Nossos profissionais">Nossos profissionais</a>
        </li>
        <li>
            <a href='quem-somos' target="_parent" title="Quem somos" class='toggle submenu'>Quem somos</a>
            <a href='quem-somos' target="_parent" title="Quem somos">Quem somos</a>
        </li>
        <li>
            <a href='home' target="_parent" title="Home" class='toggle submenu'>Home</a>
            <a href='home' target="_parent" title="Home">Home</a>
        </li>


    </ul>
</nav>