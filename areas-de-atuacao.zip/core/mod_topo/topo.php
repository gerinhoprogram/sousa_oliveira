<div class="linha-branca">
    <div class='linha'>
        <div class="colunas lg-12 md-12 pq-12">
        <!-- <i class="fab fa-whatsapp"></i> |  -->
        <i class="fas fa-phone-alt"></i> 11 5573-2096 
        <!-- <i class="fas fa-map-marker-alt"></i>&nbsp;&nbsp;
        <i class="far fa-envelope"></i>&nbsp;&nbsp;
        <i class="fab fa-facebook-square"></i>&nbsp;&nbsp;
        <i class="fab fa-instagram"></i>&nbsp;&nbsp;
        <i class="fab fa-linkedin"></i> -->
        </div>
    </div>
</div>
<div class="linha-azul">
    <div class="linha">
        <div class="colunas lg-2 md-3 pq-12 logo">
            <a href="home" target="_parent" title="<?=$ttl?>">
                <img src="core/imagens/logo.png" alt="<?=$ttl?>" title="<?=$ttl?>" width="90">
            </a>
        </div>
        <div class="colunas lg-10 md-9 pq-12" style="padding-right: 30px;">
            <?php include ('core/mod_menu/menu.php'); ?>
        </div>
    </div>
</div>