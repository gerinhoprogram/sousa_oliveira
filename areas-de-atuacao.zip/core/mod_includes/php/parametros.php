<?php $pagina = isset($_GET['pagina']) ? $_GET['pagina'] : ''; $pag = isset($_GET['pag']) ? $_GET['pag'] : ''; $action = isset($_GET['action']) ? $_GET['action'] : '';$cli_url = isset($_GET['cli_url']) ? $_GET['cli_url'] : '';$callback = isset($_GET['callback']) ? $_GET['callback'] : '';
?>
